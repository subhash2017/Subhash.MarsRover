﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Subhash.MarsRover
{
    class Program
    {
        static void Main(string[] args)
        {
            ILandingSurface landingSurface = new Plateau("10 10");
            RoverSquad roverSquad = new RoverSquad(landingSurface);

            roverSquad.DeployNewRover("1 2 N", "LMLMLMLMM");
            roverSquad.DeployNewRover("3 3 E", "MMRMMRMRRM");

            int noRovers = 2;
            int roverOneIdx = 0;
            int roverTwoIdx = 1;

            Console.ReadKey();

        }
    }
}
