﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Subhash.MarsRover
{
    public interface ILandingSurface
    {
        int Width { get; }
        int Height { get; }
    }
}
